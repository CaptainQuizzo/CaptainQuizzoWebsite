const numberPool = document.getElementById("numberPool");
const playButton = document.getElementById("playButton");
const selectedNumbersDiv = document.getElementById("selectedNumbers");
const drawnNumbersDiv = document.getElementById("drawnNumbers");
const resultText = document.getElementById("result");

const MAX_SELECTION = 10;
let selectedNumbers = [];
let drawnNumbers = [];

// Initialize number pool from 1 to 80
for (let i = 1; i <= 80; i++) {
    const numberElement = document.createElement("div");
    numberElement.classList.add("number");
    numberElement.textContent = i;
    numberElement.addEventListener("click", () => toggleSelection(i, numberElement));
    numberPool.appendChild(numberElement);
}

// Toggle number selection
function toggleSelection(number, element) {
    if (selectedNumbers.includes(number)) {
        selectedNumbers = selectedNumbers.filter(num => num !== number);
        element.classList.remove("selected");
    } else if (selectedNumbers.length < MAX_SELECTION) {
        selectedNumbers.push(number);
        element.classList.add("selected");
    }
    updateSelectedNumbersDisplay();
}

// Update selected numbers display
function updateSelectedNumbersDisplay() {
    selectedNumbersDiv.innerHTML = selectedNumbers.map(num => `<div class="selected-number">${num}</div>`).join('');
}

// Play Keno game
playButton.addEventListener("click", () => {
    if (selectedNumbers.length === 0) {
        alert("Please select at least one number to play!");
        return;
    }
    drawnNumbers = generateDrawnNumbers();
    updateDrawnNumbersDisplay();
    checkResults();
});

// Generate 20 random drawn numbers from 1 to 80
function generateDrawnNumbers() {
    const numbers = [];
    while (numbers.length < 20) {
        const randNum = Math.floor(Math.random() * 80) + 1;
        if (!numbers.includes(randNum)) {
            numbers.push(randNum);
        }
    }
    return numbers;
}

// Update drawn numbers display
function updateDrawnNumbersDisplay() {
    drawnNumbersDiv.innerHTML = drawnNumbers.map(num => `<div class="drawn-number">${num}</div>`).join('');
}

// Check results
function checkResults() {
    const matches = selectedNumbers.filter(num => drawnNumbers.includes(num));
    resultText.textContent = `You matched ${matches.length} numbers! (${matches.join(', ')})`;
}
